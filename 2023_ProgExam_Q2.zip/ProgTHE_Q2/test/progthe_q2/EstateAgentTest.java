/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package progthe_q2;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ghisy
 */
public class EstateAgentTest {
    
    public EstateAgentTest() {
        
    }

    @Test
    public void testCalculateTotalCommission() {
         EstateAgent estateAgent = new EstateAgent();
        String propertyPrice = "1000000"; // Replace with your test property price
        String commissionPercentage = "5"; // Replace with your test commission percentage

        double result = estateAgent.CalculateTotalCommission(propertyPrice, commissionPercentage);

        // Replace the expectedCommission with the expected result of your calculation
        double expectedCommission = 50000;
        
        assertEquals(expectedCommission, result, 0.001);
    }
    
    @Test
    public void testCalculateTotalCommissionunsuccesfully() {
         EstateAgent estateAgent = new EstateAgent();
        String propertyPrice = "1000000"; // Replace with your test property price
        String commissionPercentage = "105"; // Replace with your test commission percentage

        double result = estateAgent.CalculateTotalCommission(propertyPrice, commissionPercentage);

        // Replace the expectedCommission with the expected result of your calculation
        double expectedCommission = -1; // Replace with a sentinel value or use a different approach to handle validation failures
        
        assertEquals(expectedCommission, result, 0.001);
    }

    @Test
    public void testDataValidiation() {
         EstateAgent estateAgent = new EstateAgent();
        String estateAgentName = "John Doe";
        String agentLocation = "Cape Town";
        String propertyPrice = "1000000";
        String commissionPercentage = "5";

        assertTrue(estateAgent.DataValidiation(estateAgentName, agentLocation, propertyPrice, commissionPercentage));
    }
    
}

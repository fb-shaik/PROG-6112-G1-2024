/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package progthe_q2;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ghisy
 */
public class IEstateAgentTest {
    
    public IEstateAgentTest() {
    }

    @Test
    public void testCalculateTotalCommission() {
    }

    @Test
    public void testDataValidiation() {
    }

    public class IEstateAgentImpl implements IEstateAgent {

        public double CalculateTotalCommission(String propertyPriceValue, String commissionPercentageValue) {
            return 0.0;
        }

        public boolean DataValidiation(String estateAgentNameValue, String Agentlocation, String propertyPrice, String CommissionPercentage) {
            return false;
        }
    }
    
}

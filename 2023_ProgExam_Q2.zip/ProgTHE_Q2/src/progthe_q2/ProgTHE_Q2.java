/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package progthe_q2;


public class ProgTHE_Q2 {

    
    public static void main(String[] args) {
        
    }
    
}

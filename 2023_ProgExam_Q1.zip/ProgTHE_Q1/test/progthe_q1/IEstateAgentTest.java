/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package progthe_q1;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author ghisy
 */
public class IEstateAgentTest {
    
    public IEstateAgentTest() {
    }

    @Test
    public void testEstateAgentSales() {
    }

    @Test
    public void testEstateAgentCommission() {
    }

    @Test
    public void testTopEstateAgent() {
    }
    

    public class IEstateAgentImpl implements IEstateAgent {

        public double estateAgentSales(double[] propertySales) {
            return 0.0;
        }

        public double estateAgentCommission(double totalSales) {
            return 0.0;
        }

        public int topEstateAgent(double[] totalSales) {
            return 0;
        }
    }
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package progthe_q1;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;


public class EstateAgentTest {
    
    public EstateAgentTest() {
    }


    @Test
    public void testTopEstateAgent() {
         EstateAgent estateAgent = new EstateAgent();

        double[][] propertySalesArr = {
                {800000, 1500000, 2000000},
                {700000, 1200000, 1600000}};

        // Assuming the first agent has higher total sales
        int expectedTopAgentIndex = 0;
        int actualTopAgentIndex = estateAgent.topEstateAgent(estateAgent.CalculateTotalSales_ReturnsTotalSales(propertySalesArr));

        assertEquals(expectedTopAgentIndex, actualTopAgentIndex);
    }

    @Test
    public void testEstateAgentCommission() {
        EstateAgent estateAgent = new EstateAgent();

        double totalSales = 5000000; // Use any total sales amount for testing
        double expectedCommission = totalSales * 2 / 100;
        double actualCommission = estateAgent.estateAgentCommission(totalSales);

        assertEquals(expectedCommission, actualCommission);
    }

    @Test
    public void testCalculateTotalSales_ReturnsTotalSales() {
           EstateAgent estateAgent = new EstateAgent();

        double[][] propertySalesArr = {
                {800000, 1500000, 2000000},
                {700000, 1200000, 1600000}};

        double[] expectedTotalSales = {4300000, 3500000};
        double[] actualTotalSales = estateAgent.CalculateTotalSales_ReturnsTotalSales(propertySalesArr);

        assertArrayEquals(expectedTotalSales, actualTotalSales);
    }
    
}
